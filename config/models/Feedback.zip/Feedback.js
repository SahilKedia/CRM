const mongoose = require("mongoose");

const feedbackSchema = new mongoose.Schema(
  {
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
    },

    customerName: String,
    customerPhone: String,

    branch: {
      type: String,
      trim: true,
    },

    rating: {
      type: Number,
      min: 1,
      max: 5,
    },

    comments: {
      type: String,
      trim: true,
    },

    source: {
      type: String,
      enum: ["whatsapp"],
      default: "whatsapp",
    },

    submittedAt: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Feedback", feedbackSchema);